const express = require('express');
const app = express();
const port = 3000;

app.get('/', function(req, res) {
    res.send('Olá');
})

app.listen(port, () => {
    console.log(`Port=${port}`)
    class Pessoa {
        constructor(nome, email) {
            this.nome = nome;
            this.email = email;
            this.telefone = '';
            this.pessoa = {};
        }
    }
    
    class Endereco{
        constructor(rua, numero, bairro, complemento, cep, cidade, estado){
            this.rua = rua;
            this.numero = numero;
            this.bairro = bairro;
            this.complemento = complemento;
            this.cep = cep;
            this.cidade = cidade;
            this.estado = estado;
        }
    }
    class Cliente extends Pessoa {
        constructor(nome, email, cpf) {
            super(nome, email);
            if(cpf === undefined) {
                throw new Error(`O CPF é obrigatorio`);
            }
            this.sobrenome = '';
            this.cpf = cpf;
        }
    }
    class Fornecedor extends Pessoa {
        constructor(nome, email, cnpj) {
            super(nome, email);
            if(cnpj === undefined) {
                throw new Error(`O CNPJ é obrigatorio`);
            }
            this.razaoSocial = '';
            this.cnpj = cnpj;
        }
    }
    
    class Telefone {
        constructor(ddi, ddd, numero){
            if(ddi == undefined){
                this.ddi =55;
            }
        }
    }
    
    asnyc function findAll(connection, table){
        return connection.execute(`SELECT *FROM ${table};`);
    }
    asnyc function inserir(connection, table, fields, values){
        const parameters = values.map(()=> {return '?'}) .join(',')
        return connection.execute{
            `INSERT INTO ${table} (${fields}) VALUES(${parameters});`, values);
            
    }
    
    asnyc function find0ne(connection, table, id){
        return connection.execute(`SELECT *FROM ${table} WHERE id_${table} = ?;`, [id]);
    }
    
    asnyc function atualizar(connection, table, changes, id){
        return connection.execute(
                `UPDATE ${table} SET ${changes} WHERE id_${table} = ?;`, [id]);
    }
    
    asnyc function deletar(connnection, table, id){
        return connection.execute(`DELETE FROM ${table} WHERE id_${table} = ?;`, [id]);
    }
    
    asnyc function main {
        const mysql = require('mysql2/promise');
        
        const config = {
            host: 'localhost',
            user: 'root',
            password: 'root',
            database: 'petshop'
        }
    }
    
    const connection = await mysql.createConnection(config);
    
    const [rows, fields] = await mysql.createConnection(config);
    console.log(rows);
    
    let cliente = new Cliente ('Chrys', 'chrys@hotmail.com', '000.000.000-00')
    cliente.sobrenome = "Fi"
    
    let result = await inserir(
        connection,
        'cliente',
        'nome, email, cpf, sobrenome'
        [cliente.nome, cliente.email, cliente.cpf, cliente.sobrenome]
    );
    
    cliente.id = result[0].insertId;
    console.log(cliente.id);
    
    const [row, metada] = await find0ne(connection, 'cliente', cliente.id);
    console.log(row);
    
    cliente.sobrenome = 'Fia';
    cliente.email = 'chrystian@hotmail.com';
    result = await atualizar(
    connection,
    'cliente',
    sobrenome = '${cliente.sobrenome}',
    email = '${cliente.email}';
    cleinte.id
    );
    
    console.log(result);
    
    result = await deletar(connection, 'cliente', cliente.id);
    console.log(result);
    
    main();
    
        
    //var cliente1 = new Cliente('Chrys', 'chrys@hotmail.com', '123.456.789-10');
    //console.log(`Nome: ${cliente1.nome}, Email: ${cliente1.email}, CPF: ${cliente1.cpf}`);

    //var fornecedor1 = new Fornecedor('Atacado', 'atacado@hotmail.com.br', '12345678910121');
    //fornecedor1.razaoSocial = 'Atacado 1';
    //console.log(`Fornecedor1: ${fornecedor1.nome}, ${fornecedor1.razaoSocial}, ${fornecedor1.email}, ${fornecedor1.cnpj}`);

    //var endereco1 = new Endereco('RUA', "1", "BAIRRO", "CASA", "87043-220", "MGA", "ESTADO");
    //console.log(`Nome: ${endereco1.rua}, Numero: ${endereco1.numero}, Bairro: ${endereco1.bairro}, Complemento: ${endereco1.complemento}, CEP: ${endereco1.cep}, Cidade: ${endereco1.cidade}, Estado: ${endereco1.estado}`);

});
